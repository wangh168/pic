#include "MainFrame.h"


extern CAppModule _Module;

CPopWindow::CPopWindow()
{

}

CPopWindow::~CPopWindow()
{

}

LRESULT CPopWindow::OnPaint(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	CPaintDC dc(m_hWnd);

	CRect rect;
	GetClientRect(rect);
	dc.FillSolidRect(&rect, RGB(255, 0, 0));

	return 0L;
}

//////////////////////////////////////////////////////////////////////////
CMainFrame::CMainFrame()
{
}

CMainFrame::~CMainFrame()
{
}

BOOL CMainFrame::PreTranslateMessage(MSG* pMsg)
{
	return  FALSE;
}

BOOL CMainFrame::OnIdle()
{
	//static int index = 0;
	//CString str;
	//str.Format(_T("idle**********************%d\n"), index++);
	//OutputDebugString(str);
	return TRUE;
}

LRESULT CMainFrame::OnCreate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	RECT rect;
	//_popWindow.Create(m_hWnd, &rect, NULL, WS_POPUPWINDOW);
	bHandled = FALSE;

	CMessageLoop* pLoop = _Module.GetMessageLoop();
	pLoop->AddIdleHandler(this);

    GetClientRect(&rect);
    rect.left += 10;
    rect.top += 10;
    rect.right -= 10;
    rect.bottom -= 10;
   
    m_list.Create(m_hWnd, rect, _T("SysListView32"), LVS_REPORT | WS_CHILD | LVS_ALIGNLEFT | WS_BORDER | WS_TABSTOP | WS_VISIBLE | WS_CLIPCHILDREN | WS_CLIPSIBLINGS, 0);
  
    m_list.SetExtendedListViewStyle(m_list.GetExtendedListViewStyle() | LVS_EX_FULLROWSELECT |
        LVS_EX_GRIDLINES | LVS_EX_INFOTIP);

    m_list.InsertColumn(0, _T("���1"), LVCFMT_LEFT, 200);
    m_list.InsertColumn(1, _T("���2"), LVCFMT_LEFT, 200);
    m_list.AddItem(0, 0, _T("Hello world!"));
	return 0L;
}

LRESULT CMainFrame::OnDestroy(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	CMessageLoop* pLoop = _Module.GetMessageLoop();
	pLoop->RemoveIdleHandler(this);
	::PostQuitMessage(0);

	bHandled = FALSE;

	return 1L;
}

LRESULT CMainFrame::OnMovied(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
    bHandled = FALSE;
    RECT rect;
    GetClientRect(&rect);
    rect.left += 10;
    rect.top += 10;
    rect.right -= 10;
    rect.bottom -= 10;

    m_list.MoveWindow(&rect);
    return 0;
}